<?php


namespace Vanier\Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Vanier\Api\Models\PersonsModel;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Vanier\Api\Exceptions\HttpInvalidOptionException;
use Psr\Http\Message\ServerRequestInterface;

class PersonsController extends BaseController
{
    protected $pattern = "/^M-\d{4}-\d{2}$/";
    private $model = null;
    //! VAR NAMES ALL IN SNAKE CASE (UNDERSCORES)

    public function __construct() {
        $this->model = new PersonsModel();
    }

    public function handleCreatePersons(Request $request, Response $response, array $uri_args): Response
    {
        $persons = $request->getParsedBody();
        $guys = 0;

        foreach($persons as $person){
            $this->model->createPerson($person);
            $guys = $guys + 1;
        }

        $response_data = array(
            "code" => "Success",
            "message" => "Working, $guys persons created."
        );

        $payload = json_encode($response_data);
        $response->getBody()->write($payload);  
        $response = $response->withStatus(201);

        return $response->withHeader("Content-Type", "application/json");
    }

    public function handleUpdatePersons(Request $request, Response $response, array $uri_args): Response
    {
        $persons = $request->getParsedBody();
        $guys = 0;

        foreach($persons as $person){
            $person_id = $person['person_id'];
            unset($person['person_id']);
            if($this->model->updatePerson($person, $person_id)>0){
                $guys = $guys + 1;
            }
            
        }

        $response_data = array(
            "code" => "Success",
            "message" => "Working, $guys persons updated."
        );

        $payload = json_encode($response_data);
        $response->getBody()->write($payload);  
        $response = $response->withStatus(201);

        return $response->withHeader("Content-Type", "application/json");
    }

    public function handleDeletePersons(Request $request, Response $response, array $uri_args): Response
    {
        $person_ids = $request->getParsedBody();
        $guys = 0;

        foreach($person_ids as $person_id){
            if($this->model->deletePerson($person_id)>0){
                $guys = $guys + 1;
            }
            
        }

        $response_data = array(
            "code" => "Success",
            "message" => "Working, $guys persons deleted."
        );

        $payload = json_encode($response_data);
        $response->getBody()->write($payload);  
        $response = $response->withStatus(201);

        return $response->withHeader("Content-Type", "application/json");
    }

}