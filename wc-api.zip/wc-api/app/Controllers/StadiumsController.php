<?php


namespace Vanier\Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Vanier\Api\Models\StadiumsModel;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Psr\Http\Message\ServerRequestInterface;

class StadiumsController extends BaseController
{
    protected $pattern = "/^S-\d{3}$/";
    private $model = null;
    //! VAR NAMES ALL IN SNAKE CASE (UNDERSCORES)

    public function __construct() {
        $this->model = new StadiumsModel();
    }

    public function handleGetStadiums(Request $request, Response $response, array $uri_args): Response
    {
        return $this->handleGetEntities($request, $response, $uri_args, $this->model);
    }

    public function handleGetStadium(Request $request, Response $response, array $uri_args): Response
    {
        return $this->handleGetEntity($request, $response, $uri_args, $this->model);
    }

    public function handleGetStadiumMatches(Request $request, Response $response, array $uri_args) : Response{
        return $this->handleGetEntity($request, $response, $uri_args, $this->model, "Matches");
    }

}