<?php


namespace Vanier\Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Vanier\Api\Models\PlayersModel;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Psr\Http\Message\ServerRequestInterface;

class PlayersController extends BaseController
{
    protected $pattern = "/^P-\d{5}$/";
    private $players_model = null;
    //! VAR NAMES ALL IN SNAKE CASE (UNDERSCORES)
    public function __construct() {
        $this->players_model = new PlayersModel();
    }

    public function handleGetPlayers(Request $request, Response $response, array $uri_args): Response
    {
       return $this->handleGetEntities($request, $response, $uri_args, $this->players_model);
    }

    public function handleGetPlayer(Request $request, Response $response, array $uri_args) : Response{
        return $this->handleGetEntity($request, $response, $uri_args, $this->players_model);
    }

    public function handleGetPlayerGoals(Request $request, Response $response, array $uri_args) : Response{
        //? Sending "Goals" so the proper model method name is concatenated and sent.
        return $this->handleGetEntity($request, $response, $uri_args, $this->players_model, "Goals");
    }

    public function handleGetPlayerAppearances(Request $request, Response $response, array $uri_args) : Response{
        //? Sending "Appearances" so the proper model method name is concatenated and sent.
        return $this->handleGetEntity($request, $response, $uri_args, $this->players_model, "Appearances");
    }
}