<?php


namespace Vanier\Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Vanier\Api\Exceptions\HttpInvalidOptionException;
use Vanier\Api\Models\TournamentsModel;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Psr\Http\Message\ServerRequestInterface;

class TournamentsController extends BaseController
{
    protected $pattern = "/^WC-\d{4}$/";
    private $model = null;
    //! VAR NAMES ALL IN SNAKE CASE (UNDERSCORES)

    public function __construct() {
        $this->model = new TournamentsModel();
    }

    public function handleGetTournaments(Request $request, Response $response, array $uri_args): Response
    {
        //? Since I am doing filter validation before sending stuff off to the model, filters must be extracted (I don't wanna keep doing $request->getQueryParams()
        $filters = $request->getQueryParams();
        //? Must validate if the Type param is an accepted value (throw an exception otherwise)
        $type = $filters["type"] ?? null;
        if(isset($type)){
            $this->typeCheck($request, $type);
        }
        if(isset($filters['start_date']) || isset($filters['end_date'])){
            $this->dateCheck($request, [$filters['start_date'], $filters['end_date']]);
        }
        
        return $this->handleGetEntities($request, $response, $uri_args, $this->model);
    }

    public function handleGetTournament(Request $request, Response $response, array $uri_args): Response
    {
        return $this->handleGetEntity($request, $response, $uri_args, $this->model);
    }

    public function handleGetTournamentMatches(Request $request, Response $response, array $uri_args) : Response{
        return $this->handleGetEntity($request, $response, $uri_args, $this->model, "Matches");
    }

    public function typeCheck(Request $request, $type){
        //? This method throws an exception if a value is sent that isn't "men" or "women" (case insensitive)
        $sex = strtolower($type);
        if($sex!='men' && $sex!='women'){
            throw new HttpInvalidOptionException($request, "Please enter either 'men' or 'women' in the 'type' attribute. No other values are allowed.");
        }
    }

}