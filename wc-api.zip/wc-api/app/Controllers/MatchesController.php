<?php


namespace Vanier\Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Vanier\Api\Models\MatchesModel;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Vanier\Api\Exceptions\HttpInvalidOptionException;
use Psr\Http\Message\ServerRequestInterface;

class MatchesController extends BaseController
{
    protected $pattern = "/^M-\d{4}-\d{2}$/";
    private $model = null;
    //! VAR NAMES ALL IN SNAKE CASE (UNDERSCORES)

    public function __construct() {
        $this->model = new MatchesModel();
    }

    public function handleGetMatchSubstitutions(Request $request, Response $response, array $uri_args): Response
    {
        return $this->handleGetEntity($request, $response, $uri_args, $this->model, "Substitutions");
    }

    public function handleGetMatchPlayers(Request $request, Response $response, array $uri_args) : Response{
        if(isset($request->getQueryParams()["position"])){
            $this->positionCheck($request, strtolower($request->getQueryParams()["position"]));
        }
        
        return $this->handleGetEntity($request, $response, $uri_args, $this->model, "Players");
    }

    //? This is a function to check if the position sent by the player is one of the 4 available options 
    //? (as specified in the assignment instructions)
    private function positionCheck(Request $request, $position){
        if($position!='goal keeper' && $position!='defender' && $position!='midfielder' && $position!='forward'){
            throw new HttpInvalidOptionException($request, "Please enter one of the 4 available positions: goal keeper, defender, midfielder or forward.");
        }
    }

}