<?php


namespace Vanier\Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Vanier\Api\Models\TeamsModel;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Psr\Http\Message\ServerRequestInterface;

class TeamsController extends BaseController
{
    protected $pattern = "/^T-\d{2}$/";
    private $teams_model = null;
    //! VAR NAMES ALL IN SNAKE CASE (UNDERSCORES)
    public function __construct() {
        $this->teams_model = new TeamsModel();
    }

    public function handleGetTeams(Request $request, Response $response, array $uri_args): Response
    {
        return $this->handleGetEntities($request, $response, $uri_args, $this->teams_model);
    }

    public function handleGetTeam(Request $request, Response $response, array $uri_args): Response
    {
        return $this->handleGetEntity($request, $response, $uri_args, $this->teams_model);
    }

    public function handleGetTeamAppearances(Request $request, Response $response, array $uri_args) : Response{
        return $this->handleGetEntity($request, $response, $uri_args, $this->teams_model, "Appearances");
    }

}