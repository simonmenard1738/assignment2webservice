<?php

namespace Vanier\Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Vanier\Api\Exceptions\HttpInvalidOptionException;
use Vanier\Api\Exceptions\HttpInvalidPaginationException;
use Vanier\Api\Models\BaseModel;

abstract class BaseController
{
    //? since $pattern is used in basecontroller, must be set (even though BaseController itself will never be instantiated)
    protected $pattern = "";
    protected function makeResponse(Response $response, array $data, int $status_code = 200): Response
    {
        // var_dump($data);
        $json_data = json_encode($data);
        //-- Write JSON data into the response's body.        
        $response->getBody()->write($json_data);
        return $response->withStatus($status_code)->withAddedHeader(HEADERS_CONTENT_TYPE, APP_MEDIA_TYPE_JSON);
    }

    protected function assertEntity($id, Request $request){
        //? If the id supplied by the user does not match the entity's regex pattern (an attribute in its controller),
        //? an exception is thrown
        if(preg_match_all($this->pattern, $id)===0 || preg_match_all($this->pattern, $id)===false){
            throw new HttpInvalidInputException(
                $request, "No matching records found: id not found in table."
            );
        }
    }

    //? This is a generic function to handle the child controller's collection get. The 'type' attribute I added comes in handy here.
    public function handleGetEntities(Request $request, Response $response, array $uri_args, BaseModel $model): Response
    {

        //! step 1) get the list of query params
        $filters = $request->getQueryParams();

        //var_dump($filters);exit;
        $this->paginationSetter($model, $filters["page"] ?? 1, $filters["page_size"] ?? 10, $request);

        // echo "Preparing the list of players!";
        //? Step 1) We need to pull the list of players from the database
        
        //! This is why I keep the "type" property
        $function = "getAll".$model->type."s";
        $data = $model->$function($filters);

        //? Step 2) encode the list of players in json
        $payload = json_encode($data);

        //? Step 3) Write the JSON data into the response's body section
        $response->getBody()->write($payload);
        $response->withStatus(200);

        //? Step 4) Add the appropriate HTTP response headers.
        //! MAKE SURE REPRESENTATION IS ALWAYS SENT IN RESPONSE 
        return $response->withHeader("Content-Type", "application/json");
        
        //return $this->makeResponse($response, $data);
    }

    //? This is a generic function to handle the child controller's singleton get and their associated collections. 
    //? I changed all routes to specify "id" instead of {entityname_id} in order to make everything fit in one function
    public function handleGetEntity(Request $request, Response $response, array $uri_args, BaseModel $model, string $attribute = "") : Response{
        $id = $uri_args["id"];
        $filters = $request->getQueryParams();

        $this->assertEntity($id, $request);

        //? Creating function name. 
        //! EVERY MODEL FUNCTION MUST ADHERE TO THE NAMING CONVENTION OR THE WHOLE APP BREAKS
        $function = "get".$model->type.$attribute."ById";
        $info = $model->$function($id, $filters);

        $payload = json_encode($info);
        $response->getBody()->write($payload);  
        $response = $response->withStatus(200);

        if(empty($info)){
            throw new HttpInvalidInputException(
                $request, "No matching records found: player id not found in table."
            );
        }
        return $response->withHeader("Content-Type", "application/json");
    }

    protected function paginationSetter($model, $page, $page_size, Request $request){
        if(isset($page) || isset($page_size)){
            //? If the page or page_size params are comprised of non-digits (this includes negative numbers), the
            //? WS will throw an exception. If not, paginationSetter will continue as normal and update the model's pagination values.
            if(preg_match_all("/^[0-9]*$/", $page)==0 || preg_match_all("/^[0-9]*$/", $page_size)==0){
                throw new HttpInvalidPaginationException(
                    $request, 'Pagination is either negative or contains non-digit characters. Please send valid page/page_size values.'
                );
            }
        }
        $model->setPaginationOptions(
            $page,
            $page_size
        );
    }

    protected function dateCheck(Request $request, $dates){
        //? Same concept as the pagination check, but for the YYYY-MM-DD format in the dates.
        //? Placed in the BaseController in case future resources require date checking (as all sql dates are in the same format)
        foreach($dates as $date){
            if(!preg_match("/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/", $date)){
                throw new HttpInvalidOptionException($request, "Please enter dates in a YYYY-MM-DD format, otherwise they cannot be accepted.");
            }
        }
    }
}
