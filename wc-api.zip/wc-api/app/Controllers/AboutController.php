<?php

declare(strict_types=1);

namespace Vanier\Api\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class AboutController extends BaseController
{
    public function handleAboutWebService(Request $request, Response $response, array $uri_args): Response
    {
        $data = array(
            'about' => 'Welcome! This is a Web service that provides information about several Soccer/Football World Cup Tournaments.',
            'resources' => array(
                '/players' => array(
                    'description'=> 'Gets a list of players appearing in a World Cup Tournament. ',
                    'filters'=>'first_name, last_name, dob, position, gender'
                ),
                '/players/{player_id}' => array(
                    'description'=> 'Gets all info on a specific player, specified by its ID.',
                    'filters'=>'none'
                ),
                '/players/{player_id}/goals' => array(
                    'description'=> 'Gets info on goals scored by a specific player, specified by their ID.',
                    'filters'=>'tournament, match'
                ),
                '/players/{player_id}/appearances' => array(
                    'description'=> 'Gets info on all match appearances by a specific player, specified by their ID.',
                    'filters'=>'none'
                ),
                '/teams' => array(
                    'description'=> 'Gets info on all teams having an appearance in a World Cup tournaments.',
                    'filters'=>'region'
                ),
                '/teams/{team_id}/appearances' => array(
                    'description'=> 'Gets info on all matches a team participated in during a World Cup tournaments.',
                    'filters'=>'match_result'
                ),
                '/tournaments' => array(
                    'description'=> 'Gets info on all World Cup tournaments throughout history (from the 1930s onwards).',
                    'filters'=>'start_date. end_date, winner, host_country, type'
                ),
                '/tournaments/{tournament_id}/matches' => array(
                    'description'=> 'Gets info on all matches in a given World Cup tournament.',
                    'filters'=>'stage'
                ),
                '/matches/{match_id}/substitutions' => array(
                    'description'=> 'Gets info on all player substitutions in a given World Cup match.',
                    'filters'=>'period'
                ),
                '/stadiums' => array(
                    'description'=> 'Gets info on all stadiums that have ever hosted a World Cup match.',
                    'filters'=>'country, city, capacity'
                ),
                '/stadiums/{stadium_id}/matches' => array(
                    'description'=> 'Gets info on all matches happening in a specific stadium (denoted by its id).',
                    'filters'=>'tournament, stage'
                ),
            )
        );
        return $this->makeResponse($response, $data);
    }
}
