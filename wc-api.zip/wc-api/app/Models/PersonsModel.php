<?php

declare(strict_types=1);

namespace Vanier\Api\Models;

use PDO;
use Exception;
use Vanier\Api\Helpers\PaginationHelper;

/**
 * A wrapper class for the PDO MySQL API.
 * This class can be extended for further customization.
 */
class PersonsModel extends BaseModel
{
    public function __construct()
    {
        $this->type = "Person";
        parent::__construct();
    }

    public function createPerson(array $person_data) : mixed {
        return $this->insert('persons',$person_data);
    }

    public function updatePerson(array $person_data, int $person_id) : mixed {
        return $this->update('persons',$person_data, ["person_id" => $person_id]);
    }
    
    public function deletePerson($person_id) : mixed {
        return $this->delete('persons',["person_id" => $person_id]);
    }

}

?>