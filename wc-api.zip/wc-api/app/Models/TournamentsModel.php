<?php

declare(strict_types=1);

namespace Vanier\Api\Models;

use PDO;
use Exception;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Vanier\Api\Exceptions\HttpInvalidOptionException;
use Vanier\Api\Helpers\PaginationHelper;

/**
 * A wrapper class for the PDO MySQL API.
 * This class can be extended for further customization.
 */
class TournamentsModel extends BaseModel
{
    public function __construct()
    {
        $this->type = "Tournament";
        parent::__construct();
    }
    public function getAllTournaments($filters): array
    {
        $filter_values = [];
        $sql = "SELECT * FROM tournaments WHERE 1";

        if(isset($filters["winner"])){
            $sql .= " AND winner LIKE CONCAT(:winner, '%') ";
            $filter_values["winner"] = $filters["winner"];
        }

        if(isset($filters["host_country"])){
            $sql .= " AND host_country LIKE CONCAT(:host_country, '%') ";
            $filter_values["host_country"] = $filters["host_country"];
        }

        if(isset($filters["type"])){
            $sex = strtolower($filters["type"]);
            if($sex="men" || $sex= "women"){
                //? Selects only the part of the string where "women" or "men" will pop up (char 11) and check the sex of the players in the tournament
                $sql .= " AND SUBSTRING(tournament_name, 11, 6) LIKE CONCAT(:type, '%')";
                $filter_values["type"] = $filters["type"];
            }else{
                //?idk
            }
            
        }

        //!These two will return any tournament between the two dates.
        if(isset($filters["start_date"])){
            $sql .= " AND start_date > :start_date";
            $filter_values["start_date"] = $filters["start_date"];
        }

        if(isset($filters["end_date"])){
            $sql .= " AND end_date < :end_date";
            $filter_values["end_date"] = $filters["end_date"];
        }



        //return (array)$this->fetchAll($sql, $filter_values);
        return (array)$this->paginateAll($sql, $filter_values);
    }

    public function getTournamentById(string $tournament_id) : mixed{
        $sql = "SELECT * FROM tournaments WHERE tournament_id = :id";
        return $this->fetchAll($sql, ["id" => $tournament_id]);
    }

    public function getTournamentMatchesById(string $id, $filters): mixed{
        $filter_values = [];
        $sql = "SELECT * FROM matches WHERE tournament_id = :id";
        $filter_values["id"] = $id;

        if(isset($filters["stage"])){
            $sql .= " AND stage_name LIKE CONCAT('%',:stage, '%')";
            $filter_values["stage"] = $filters["stage"];
        }
        
        $response["tournament"] = $this->getTournamentById($id);
        $response["matches"] = $this->paginateAll($sql, $filter_values);
        return $response;
    }
}

?>