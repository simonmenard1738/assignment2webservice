<?php

declare(strict_types=1);

namespace Vanier\Api\Models;

use PDO;
use Exception;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Vanier\Api\Exceptions\HttpInvalidOptionException;
use Vanier\Api\Helpers\PaginationHelper;

/**
 * A wrapper class for the PDO MySQL API.
 * This class can be extended for further customization.
 */
class StadiumsModel extends BaseModel
{
    public function __construct()
    {
        $this->type = "Stadium";
        parent::__construct();
    }
    public function getAllStadiums($filters): array
    {
        $filter_values = [];
        $sql = "SELECT * FROM stadiums WHERE 1";

        if(isset($filters["country"])){
            $sql .= " AND country_name LIKE CONCAT(:winner, '%') ";
            $filter_values["country_name"] = $filters["country"];
        }

        if(isset($filters["city"])){
            $sql .= " AND city_name LIKE CONCAT(:city_name, '%') ";
            $filter_values["city_name"] = $filters["city"];
        }

        if(isset($filters["capacity"])){
            $sql .= " AND stadium_capacity > :stadium_capacity";
            $filter_values["stadium_capacity"] = $filters["capacity"];
        }
        //return (array)$this->fetchAll($sql, $filter_values);
        return (array)$this->paginateAll($sql, $filter_values);
    }

    public function getStadiumById(string $id) : mixed{
        $sql = "SELECT * FROM stadiums WHERE stadium_id = :id";
        return $this->fetchAll($sql, ["id" => $id]);
    }

    public function getStadiumMatchesById(string $id, $filters): mixed{
        $filter_values = [];
        $sql = "SELECT m.* FROM matches m, tournaments t WHERE m.stadium_id = :id AND t.tournament_id = m.tournament_id";
        $filter_values["id"] = $id;

        if(isset($filters["stage"])){
            $sql .= " AND stage_name LIKE CONCAT('%',:stage, '%')";
            $filter_values["stage"] = $filters["stage"];
        }
        if(isset($filters["tournament"])){
            $sql .= " AND tournament_name LIKE CONCAT('%',:tournament, '%')";
            $filter_values["tournament"] = $filters["tournament"];
        }
        
        $response["stadium"] = $this->getStadiumById($id);
        $response["matches"] = $this->paginateAll($sql, $filter_values);
        return $response;
    }

    
}

?>