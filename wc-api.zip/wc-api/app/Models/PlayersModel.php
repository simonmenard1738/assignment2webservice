<?php

declare(strict_types=1);

namespace Vanier\Api\Models;

use PDO;
use Exception;
use Vanier\Api\Helpers\PaginationHelper;

/**
 * A wrapper class for the PDO MySQL API.
 * This class can be extended for further customization.
 */
class PlayersModel extends BaseModel
{
    public function __construct()
    {
        $this->type = "Player";
        parent::__construct();
    }
    public function getAllPlayers($filters): array
    {
        $filter_values = [];
        $sql = "SELECT * FROM players WHERE 1";

        if(isset($filters["first_name"])){
            $sql .= " AND given_name LIKE CONCAT(:first_name, '%') ";
            $filter_values["first_name"] = $filters["first_name"];
        }

        if(isset($filters["dob"])){
            $sql .= " AND birth_date > :dob";
            $filter_values["dob"] = $filters["dob"];
        }

        if(isset($filters["last_name"])){
            $sql .= " AND family_name LIKE CONCAT(:last_name, '%')";
            $filter_values["last_name"] = $filters["last_name"];
        }

        if(isset($filters["position"])){
            //ADD VALIDATION FOR THIS
            $sql .= " AND :position = 1";
            $filter_values["position"] = $filters["position"];
        }

        if(isset($filters["gender"])){
            //? I set gender to respond to either "female" or "woman". Any other reply will result in a list of male (or gnc/nb) players
            //? I decided to not throw InvalidOptionExceptions as in recent years, there have been gender non conforming/ non binary
            //? players in soccer tournaments, so for future growth and implementation, this is the best way to handle it.
            $is_woman = 0;
            if(strtolower($filters["gender"])=="female" || strtolower($filters["gender"])=="woman"){
                $is_woman = 1;
            }
            $sql .= " AND female = $is_woman";
        }



        //return (array)$this->fetchAll($sql, $filter_values);
        return (array)$this->paginateAll($sql, $filter_values);
    }

    public function getPlayerById(string $player_id) : mixed{
        $sql = "SELECT * FROM PLAYERS WHERE player_id = :id";
        return $this->fetchAll($sql, ["id" => $player_id]);
    }

    public function getPlayerGoalsById(string $player_id, $filters): mixed{
        $filter_values = [];
        $sql = "SELECT g.minute_label, g.minute_regulation, g.match_period, tm.*, t.*, m.* FROM goals g, tournaments t, matches m, teams tm WHERE g.tournament_id = t.tournament_id AND g.team_id = tm.team_id AND g.match_id = m.match_id AND g.player_id = :id";

        $filter_values["id"] = $player_id;
        if(isset($filters["tournament"])){
            $sql .= " AND tournament_name LIKE CONCAT('%', :tournament, '%')";
            $filter_values["tournament"] = $filters["tournament"];
        }
        if(isset($filters["match"])){
            $sql .= " AND match_name LIKE CONCAT('%', :match, '%')";
            $filter_values["match"] = $filters["match"];
        }
        
        $response["player"] = $this->getPlayerById($player_id);
        $response["goals"] = $this->paginateAll($sql, $filter_values);
        return $response;
    }

    public function getPlayerAppearancesById(string $player_id): mixed{
        $sql = "SELECT m.* FROM tournaments t, matches m, player_appearances pa WHERE m.match_id = pa.match_id AND pa.tournament_id = t.tournament_id AND pa.player_id = '$player_id'";
        
        $response["player"] = $this->getPlayerById($player_id);
        $response["appearances"] = $this->paginateAll($sql);
        return $response;
    }
}

?>