<?php

declare(strict_types=1);

namespace Vanier\Api\Models;

use PDO;
use Exception;
use Vanier\Api\Exceptions\HttpInvalidInputException;
use Vanier\Api\Exceptions\HttpInvalidOptionException;
use Vanier\Api\Helpers\PaginationHelper;

/**
 * A wrapper class for the PDO MySQL API.
 * This class can be extended for further customization.
 */
class MatchesModel extends BaseModel
{
    public function __construct()
    {
        $this->type = "Match";
        parent::__construct();
    }

    public function getMatchById(string $id) : mixed{
        $sql = "SELECT * FROM matches WHERE match_id = :id";
        return $this->fetchAll($sql, ["id" => $id]);
    }

    public function getMatchSubstitutionsById(string $id, $filters): mixed{
        $filter_values = [];
        $sql = "SELECT * FROM substitutions WHERE match_id = :id";
        $filter_values["id"] = $id;

        if(isset($filters["period"])){
            $sql .= " AND match_period LIKE CONCAT(:period, '%')";
            $filter_values["period"] = $filters["period"];
        }
        
        $response["match"] = $this->getMatchById($id);
        $response["substitutions"] = $this->paginateAll($sql, $filter_values);
        return $response;
    }

    public function getMatchPlayersById(string $id, $filters): mixed{
        $sql = "SELECT p.* FROM matches m, player_appearances pa, players p WHERE m.match_id = :id AND pa.match_id = m.match_id AND p.player_id = pa.player_id";
        $filter_values["id"] = $id;

        if(isset($filters["position"])){
            $position = strtolower($filters["position"]);
            if($position=='goal keeper' || $position=='defender' || $position=='midfielder' || $position=='forward'){
                $sql .= " AND position = :position";
                $filter_values["position"] = $filters["position"];
            }
            //? This if statement is purely to make absolutely sure (in case the exception in controller messes up)
            //? that invalid values will not be sent via SQL query.
        }
        
        $response["match"] = $this->getMatchById($id);
        $response["players"] = $this->paginateAll($sql, $filter_values);
        return $response;
    }
}

?>