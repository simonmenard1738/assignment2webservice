<?php

declare(strict_types=1);

namespace Vanier\Api\Models;

use PDO;
use Exception;
use Vanier\Api\Helpers\PaginationHelper;

/**
 * A wrapper class for the PDO MySQL API.
 * This class can be extended for further customization.
 */
class TeamsModel extends BaseModel
{
    public function __construct()
    {
        $this->type = "Team";
        parent::__construct();
    }
    public function getAllTeams($filters): array
    {
        $filter_values = [];
        $sql = "SELECT * FROM teams WHERE 1";

        if(isset($filters["region"])){
            $sql .= " AND region_name LIKE CONCAT(:region, '%') ";
            $filter_values["region"] = $filters["region"];
        }
        //return (array)$this->fetchAll($sql, $filter_values);
        return (array)$this->paginateAll($sql, $filter_values);
    }

    public function getTeamById(string $team_id) : mixed{
        $sql = "SELECT * FROM teams WHERE team_id = :id";
        return $this->fetchAll($sql, ["id" => $team_id]);
    }

    public function getTeamAppearancesById(string $team_id) : mixed{
        $sql = "SELECT m.* FROM teams t, team_appearances ta, matches m WHERE t.team_id = '$team_id' AND ta.team_id = '$team_id' and m.match_id = ta.match_id";

        $response["team"] = $this->getTeamById($team_id);
        $response["appearances"] = $this->paginateAll($sql);
        return $response;
    }


}

?>