<?php

namespace Vanier\Api\Helpers;
use GuzzleHttp\Client;

class WebServiceInvokerHelper
{
    private array $client_options = [];
    public function __construct($args = []){
        //! YOU CAN PASS A LIST OF OPTIONS IF YOU WANT TO CUSTOMIZE THE GUZZLE CLIENT,
        //! SUCH AS BASE URI, TIME OUT, ETC
        $this->client_options = $args;
    }

    public function invokeURI(string $resource_uri) : mixed{
        // we will initiate a get request
        
        $client = new Client($this->client_options);
        $response = $client->get($resource_uri);
        //! we need to process the response

        //? Validate response: status rode, response headerL
        //? acccept type, etc.
        if($response->getStatusCode() === 200){
            //? We have a valid response , must now process it.
            //? prepare the data structure to be parsed.
            $leagues = $response->getBody()!=null ? json_decode($response->getBody()->getContents()) : false;
            $parsed_leagues = [];
            foreach ($leagues->countries as $key => $league){
                $parsed_leagues[$key]["idLeague"] = $league->idLeague;
                $parsed_leagues[$key]["strSport"] = $league->strSport;
                $parsed_leagues[$key]["strLeague"] = $league->strLeague;
                $parsed_leagues[$key]["strGender"] = $league->strGender;
                $parsed_leagues[$key]["intFormedYear"] = $league->intFormedYear;
                $parsed_leagues[$key]["strCurrentSeason"] = $league->strCurrentSeason;
                $parsed_leagues[$key]["strCountry"] = $league->strCountry;
            }
            return $parsed_leagues;
        }else{
            return $this->makeError($response->getStatusCode(), $response->getReasonPhrase());
        }
    }
    private function makeError($status_code, $message){
        return ["status_code" => $status_code, "message" => $message];
    }
}
