<?php declare(strict_types=1);

use Monolog\Logger;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

use Vanier\Api\Controllers\AboutController;
use Vanier\Api\Controllers\MatchesController;
use Vanier\Api\Controllers\PlayersController;
use Vanier\Api\Controllers\StadiumsController;
use Vanier\Api\Controllers\TeamsController;
use Vanier\Api\Controllers\TournamentsController;
use Vanier\Api\Controllers\PersonsController;
use Vanier\Api\Helpers\DateTimeHelper;

// Import the app instance into this file's scope.
global $app;

// TODO: Add your app's routes here.
//! The callbacks must be implemented in a controller class.
//! The Vanier\Api must be used as namespace prefix. 

//? Note: all entities have {id} in their endpoint instead of {entityname_id} in order to
//? work with the generic param names in the BaseController (getEntity and getEntities)

//* ROUTE: GET /
$app->get('/', [AboutController::class, 'handleAboutWebService']); 

//* ROUTE: GET /players
$app->get('/players', [PlayersController::class, 'handleGetPlayers']);

//* ROUTE: GET /players/{id}
$app->get('/players/{id}', [PlayersController::class, 'handleGetPlayer']);

//* ROUTE: GET /players/{id}/goals
$app->get('/players/{id}/goals', [PlayersController::class, 'handleGetPlayerGoals']);

//* ROUTE: GET /players/{id}/goals
$app->get('/players/{id}/appearances', [PlayersController::class, 'handleGetPlayerAppearances']);

//* ROUTE: GET /teams
$app->get('/teams', [TeamsController::class, 'handleGetTeams']);

//* ROUTE: GET /teams/{id}
$app->get('/teams/{id}', [TeamsController::class, 'handleGetTeam']);

//* ROUTE: GET /teams/{id}/appearances
$app->get('/teams/{id}/appearances', [TeamsController::class, 'handleGetTeamAppearances']);

//* ROUTE: GET /tournaments
$app->get('/tournaments', [TournamentsController::class, 'handleGetTournaments']);

//* ROUTE: GET /tournaments/{id}
$app->get('/tournaments/{id}', [TournamentsController::class, 'handleGetTournament']);

//* ROUTE: GET /tournaments/{id}/matches
$app->get('/tournaments/{id}/matches', [TournamentsController::class, 'handleGetTournamentMatches']);

//* ROUTE: GET /matches/{id}/substitutions
$app->get('/matches/{id}/substitutions', [MatchesController::class, 'handleGetMatchSubstitutions']);

//* ROUTE: GET /matches/{id}/players
$app->get('/matches/{id}/players', [MatchesController::class, 'handleGetMatchPlayers']);

//* ROUTE: GET /stadiums
$app->get('/stadiums', [StadiumsController::class, 'handleGetStadiums']);

//* ROUTE: GET /stadiums/{id}/matches
$app->get('/stadiums/{id}/matches', [StadiumsController::class, 'handleGetStadiumMatches']);

//* ROUTE: POST /persons
$app->post('/persons', [PersonsController::class, 'handleCreatePersons']);

//* ROUTE: PUT /persons
$app->put('/persons', [PersonsController::class, 'handleUpdatePersons']);

//* ROUTE: DELETE /persons
$app->delete('/persons', [PersonsController::class, 'handleDeletePersons']);

//* ROUTE: GET /hello
$app->get('/hello', function (Request $request, Response $response, $args) {

    $logger = new Logger('access');
    $logger->pushHandler(new StreamHandler(APP_ACCESS_LOGS_PATH, Logger::DEBUG));

    $now = DateTimeHelper::getDateAndTime(DateTimeHelper::D_M_Y);        
    $response->getBody()->write("Reporting! Hello there! The current time is: ".$now);            
    return $response;
});
