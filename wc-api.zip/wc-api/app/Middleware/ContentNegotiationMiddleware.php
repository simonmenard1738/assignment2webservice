<?php declare(strict_types=1);

namespace Vanier\Api\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Server\MiddlewareInterface;
use Vanier\Api\Exceptions\HttpNotAcceptableException;
use Slim\Psr7\Response;

class ContentNegotiationMiddleware implements MiddlewareInterface
{
    public function process(Request $request, RequestHandler $handler): ResponseInterface
    {
        //put handling here, check request accept header
        $response = new Response();
        $accept = $request->getHeaderLine('Accept');
        $data = array();
        if(!str_contains("application/json", $accept)){
            //? Setting the status code, and the data to be later encrypted to json and returned to the client.
            $response = $response->withStatus(406);
            $data = [
                "code" => "406", 
                "message"=>"Bad Request", 
                "description"=>"Please enter the type of data we will return in the 'accept' header. Your current accept type is of $accept and we only return application/json."
            ];

            //? Setting the response's body to the json encoding of the previous array and returning it.
            $response->getBody()->write(json_encode($data));  
            return $response->withHeader("Content-Type", "application/json");

            //? Throwing 406 not acceptable exception, commented out as to the teacher's requests.
            //throw new HttpNotAcceptableException($request, "Please enter the type of data we will return in the 'accept' header. Your current accept type is of $accept and we only return application/json.");
        }
        //! DO NOT remove or change the following statements. 
        
        $response = $handler->handle($request);
        return $response;
    }    
}