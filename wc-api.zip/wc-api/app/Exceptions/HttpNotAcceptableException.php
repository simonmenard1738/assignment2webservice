<?php

    //declare(strict_types=1);

    namespace Vanier\Api\Exceptions;
    use Slim\Exception\HttpSpecializedException;


    use Psr\Http\Message\ServerRequestInterface;
    use Throwable;

    class HttpNotAcceptableException extends HttpSpecializedException{
        /**
         * @var int
         */
        protected $code = 406;

        /**
         * @var string
         */
        protected $message = 'Not Acceptable.';
        protected string $title = '406 Not Acceptable';

        //? Assuming that the data hosted here will always be application/json, if not, should be changed.
        protected string $description = 'The content type requested is not the same as the one that was about to be returned (application/json).';
    
    }
?>