<?php

    //declare(strict_types=1);

    namespace Vanier\Api\Exceptions;
    use Slim\Exception\HttpSpecializedException;


    use Psr\Http\Message\ServerRequestInterface;
use Slim\Exception\HttpException;
use Throwable;

    class HttpInvalidOptionException extends HttpException{
        /**
         * @var int
         */
        protected $code = 400;

        /**
         * @var string
         */
        protected $message = 'Invalid query parameters.';

        protected string $title = '400 Bad Request';
        protected string $description = 'User entered contextually incorrect query parameters.';
    
    }
?>