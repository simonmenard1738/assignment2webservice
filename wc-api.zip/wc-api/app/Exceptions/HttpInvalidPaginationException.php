<?php

    //declare(strict_types=1);

    namespace Vanier\Api\Exceptions;
    use Slim\Exception\HttpSpecializedException;


    use Psr\Http\Message\ServerRequestInterface;
    use Throwable;

    class HttpInvalidPaginationException extends HttpSpecializedException{
        /**
         * @var int
         */
        protected $code = 400;

        /**
         * @var string
         */
        protected $message = 'Bad Request.';
        protected string $title = '400 Bad Request';
        protected string $description = 'Pagination is either negative or contains non-digit characters. Please send valid page/page_size values.';
    
    }
?>